# Dataset > 2023-08-04 7:04pm
https://universe.roboflow.com/suhasini-gupta-ehllj/dataset-agauc

Provided by a Roboflow user
License: CC BY 4.0


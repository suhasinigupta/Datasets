# Indepence > 2023-08-05 10:37pm
https://universe.roboflow.com/suhasini-gupta-ehllj/indepence

Provided by a Roboflow user
License: CC BY 4.0


# Flag_detection > 2023-08-10 4:40pm
https://universe.roboflow.com/suhasini-gupta-ehllj/flag_detection-0oukw

Provided by a Roboflow user
License: CC BY 4.0

